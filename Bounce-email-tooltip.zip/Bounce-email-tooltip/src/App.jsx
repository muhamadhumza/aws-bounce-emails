import "./App.css";
import ControlledTooltips from "./components/tooltipTwo";

function App() {
  return (
    <>
      <ControlledTooltips />
    </>
  );
}

export default App;
